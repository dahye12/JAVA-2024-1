/*
 * 작성일 : 2024년 4월 30일 
 * 작성자 : 202213015 컴퓨터공학과 박다혜 
 * 설명 : 메인메소드가 있는 클래스 . 
 * 클래스로부터 객체 생성하여 계산 결과 출력한다. plusminus 파일이랑 연결
 * 
 */
public class Calculator {

	public static void main(String[] args) {
		// plusMinus 클래스로부터 객체 생성. 
		PlusMinus pm = new PlusMinus(); //pm은 클래스로 가기위한 통로 
		
		// 변수 선언
		String sum, cha;
		
		// pm객체를 통해 PlusMinus 클래스에 있는 메소드 호출 
		sum = pm.plus(10,20); 
		System.out.println(sum);
		
		

	}

}
