
public class MultiDiv {

}
